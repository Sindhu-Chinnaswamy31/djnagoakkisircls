from django.contrib import admin
from Serializers.models import SampleModel

# Register your models here.
admin.site.register(SampleModel)