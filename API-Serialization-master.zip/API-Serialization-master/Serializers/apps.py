from django.apps import AppConfig


class SerializersConfig(AppConfig):
    name = 'Serializers'
