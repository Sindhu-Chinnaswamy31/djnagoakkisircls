from django.contrib import admin
from api.models import UserProfile
# Register your models here.
admin.site.register(UserProfile)